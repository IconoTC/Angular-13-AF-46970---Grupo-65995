import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mio'
})
export class MioPipe implements PipeTransform {

  transform(dato: unknown, ...args: unknown[]): unknown {
    // Retornar el dato modificado segun los argumentos recibidos
    return "dato modificado";
  }

}
