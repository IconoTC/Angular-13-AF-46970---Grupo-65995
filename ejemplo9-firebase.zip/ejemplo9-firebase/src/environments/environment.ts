// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyAdhUa_KOindhMVFQ-DgZMWrYo5z9zcWo8",
    authDomain: "angular-12-julio-anabel.firebaseapp.com",
    projectId: "angular-12-julio-anabel",
    storageBucket: "angular-12-julio-anabel.appspot.com",
    messagingSenderId: "1028084679755",
    appId: "1:1028084679755:web:2e6e7d23a3a6d7f87079ce"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
