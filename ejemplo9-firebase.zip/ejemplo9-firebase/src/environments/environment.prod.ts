export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAdhUa_KOindhMVFQ-DgZMWrYo5z9zcWo8",
    authDomain: "angular-12-julio-anabel.firebaseapp.com",
    projectId: "angular-12-julio-anabel",
    storageBucket: "angular-12-julio-anabel.appspot.com",
    messagingSenderId: "1028084679755",
    appId: "1:1028084679755:web:2e6e7d23a3a6d7f87079ce"
  }
};
